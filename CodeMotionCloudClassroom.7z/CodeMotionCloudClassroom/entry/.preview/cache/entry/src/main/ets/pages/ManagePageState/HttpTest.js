import http from '@ohos:net.http';
class HttpTest extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__jsonStr = new ObservedPropertySimplePU('', this, "jsonStr");
        this.Public = 'http://4f2dc7b0.r26.cpolar.top/posts';
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.jsonStr !== undefined) {
            this.jsonStr = params.jsonStr;
        }
        if (params.Public !== undefined) {
            this.Public = params.Public;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__jsonStr.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__jsonStr.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get jsonStr() {
        return this.__jsonStr.get();
    }
    set jsonStr(newValue) {
        this.__jsonStr.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/ManagePageState/HttpTest.ets(10:5)");
            Column.width('100%');
            Column.height('100%');
            Column.justifyContent(FlexAlign.Center);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`${this.jsonStr}`);
            Text.debugLine("pages/ManagePageState/HttpTest.ets(11:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel(`获取数据`);
            Button.debugLine("pages/ManagePageState/HttpTest.ets(12:7)");
            Button.onClick(() => {
                // 获取公网数据
                // 1. 第一步:创建Http数据
                const ReturnHttp = http.createHttp();
                // 2. 第二步:请求公网数据
                ReturnHttp.request(this.Public)
                    .then((response) => {
                    // 3. 通过Response对象获取数据
                    const data = response.result.toString();
                    console.log(data);
                    this.jsonStr = data;
                })
                    .catch(err => {
                    console.error('jsondata', err.message);
                });
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new HttpTest(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=HttpTest.js.map