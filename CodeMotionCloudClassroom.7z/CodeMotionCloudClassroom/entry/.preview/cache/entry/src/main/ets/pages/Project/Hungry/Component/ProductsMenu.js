import { ProductItem } from '@bundle:com.example.codemotioncloudclassroom/entry/ets/pages/Project/Hungry/Component/ProductItem';
export class ProductsMenu extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__MenuBarList = new ObservedPropertyObjectPU(['必点爆款', '买一送一', '单价套餐', '多人套餐'], this, "MenuBarList");
        this.__categoryList = new SynchedPropertyObjectTwoWayPU(params.categoryList, this, "categoryList");
        this.__selectItem = new ObservedPropertySimplePU(0, this, "selectItem");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.MenuBarList !== undefined) {
            this.MenuBarList = params.MenuBarList;
        }
        if (params.selectItem !== undefined) {
            this.selectItem = params.selectItem;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__MenuBarList.purgeDependencyOnElmtId(rmElmtId);
        this.__categoryList.purgeDependencyOnElmtId(rmElmtId);
        this.__selectItem.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__MenuBarList.aboutToBeDeleted();
        this.__categoryList.aboutToBeDeleted();
        this.__selectItem.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get MenuBarList() {
        return this.__MenuBarList.get();
    }
    set MenuBarList(newValue) {
        this.__MenuBarList.set(newValue);
    }
    get categoryList() {
        return this.__categoryList.get();
    }
    set categoryList(newValue) {
        this.__categoryList.set(newValue);
    }
    get selectItem() {
        return this.__selectItem.get();
    }
    set selectItem(newValue) {
        this.__selectItem.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Project/Hungry/Component/ProductsMenu.ets(11:5)");
            Row.width('100%');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 页面左侧菜单栏
            Column.create();
            Column.debugLine("pages/Project/Hungry/Component/ProductsMenu.ets(13:7)");
            // 页面左侧菜单栏
            Column.width('20%');
            // 页面左侧菜单栏
            Column.height('100%');
            // 页面左侧菜单栏
            Column.backgroundColor('#F2F2F2');
            // 页面左侧菜单栏
            Column.borderRadius(100);
            if (!isInitialRender) {
                // 页面左侧菜单栏
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, index) => {
                const item = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create(item.category_name);
                    Text.debugLine("pages/Project/Hungry/Component/ProductsMenu.ets(15:11)");
                    Text.fontSize(12);
                    Text.width('100%');
                    Text.height(55);
                    Text.textAlign(TextAlign.Center);
                    Text.backgroundColor(this.selectItem == index ? '#FFFFFF' : '#F2F2F2');
                    Text.onClick(() => {
                        this.selectItem = index;
                    });
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
            };
            this.forEachUpdateFunction(elmtId, this.categoryList, forEachItemGenFunction, undefined, true, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        // 页面左侧菜单栏
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 页面右侧的商品列表
            Column.create();
            Column.debugLine("pages/Project/Hungry/Component/ProductsMenu.ets(31:7)");
            // 页面右侧的商品列表
            Column.width('80%');
            // 页面右侧的商品列表
            Column.height('100%');
            if (!isInitialRender) {
                // 页面右侧的商品列表
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create();
            List.debugLine("pages/Project/Hungry/Component/ProductsMenu.ets(32:9)");
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            var _a;
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, index) => {
                const item = _item;
                {
                    const isLazyCreate = true;
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, isLazyCreate);
                        ListItem.debugLine("pages/Project/Hungry/Component/ProductsMenu.ets(34:13)");
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        ListItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        {
                            this.observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                if (isInitialRender) {
                                    ViewPU.create(new 
                                    // 将每个商品抽取形成一个组件
                                    ProductItem(this, { ProductInfo: item }, undefined, elmtId));
                                }
                                else {
                                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                        }
                        ListItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        {
                            this.observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                if (isInitialRender) {
                                    ViewPU.create(new 
                                    // 将每个商品抽取形成一个组件
                                    ProductItem(this, { ProductInfo: item }, undefined, elmtId));
                                }
                                else {
                                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                        }
                        ListItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, (_a = this.categoryList[this.selectItem]) === null || _a === void 0 ? void 0 : _a.category_products, forEachItemGenFunction, undefined, true, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        List.pop();
        // 页面右侧的商品列表
        Column.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=ProductsMenu.js.map