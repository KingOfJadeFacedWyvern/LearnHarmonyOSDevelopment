import promptAction from '@ohos:promptAction';
class NavigationDemo extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.arr = [
            '笔记1', '笔记2', '笔记3', '笔记4', '笔记4', '笔记5', '笔记6', '笔记7', '笔记8', '笔记9', '笔记10', '笔记11', '笔记12'
        ];
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.arr !== undefined) {
            this.arr = params.arr;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/NavigationDemo.ets(12:5)");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#F1F3F5');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Navigation.create();
            Navigation.debugLine("pages/NavigationDemo.ets(13:7)");
            Navigation.title('全部笔记');
            Navigation.titleMode(NavigationTitleMode.Mini);
            Navigation.menus([
                { value: '新增', icon: './Images/new.png', action: () => {
                        promptAction.showToast({ message: '添加新增' });
                    } },
                { value: '历史', icon: './Images/history.png', action: () => {
                        promptAction.showToast({ message: '菜单历史' });
                    } },
                { value: '收藏', icon: './Images/collect.png', action: () => {
                        promptAction.showToast({ message: '菜单收藏' });
                    } },
            ]);
            Navigation.toolBar({
                items: [
                    {
                        value: '笔记',
                        icon: './Images/todo.png',
                        action: () => {
                            promptAction.showToast({ message: '笔记' });
                        }
                    },
                    { value: '收藏', icon: './Images/todo.png', action: () => {
                            promptAction.showToast({ message: '收藏' });
                        } },
                ]
            });
            Navigation.hideBackButton(true);
            if (!isInitialRender) {
                Navigation.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //   内容区
            TextInput.create({ placeholder: '搜索笔记...' });
            TextInput.debugLine("pages/NavigationDemo.ets(15:9)");
            //   内容区
            TextInput.width('90%');
            //   内容区
            TextInput.backgroundColor(Color.White);
            //   内容区
            TextInput.margin({ top: 15 });
            if (!isInitialRender) {
                //   内容区
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            List.create({ space: 12 });
            List.debugLine("pages/NavigationDemo.ets(19:9)");
            List.width('100%');
            List.height(500);
            List.margin({ top: 12 });
            List.padding({ left: '10%', right: '10%' });
            if (!isInitialRender) {
                List.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, index) => {
                const item = _item;
                {
                    const isLazyCreate = true;
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, isLazyCreate);
                        ListItem.debugLine("pages/NavigationDemo.ets(21:13)");
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const observedShallowRender = () => {
                        this.observeComponentCreation(itemCreation);
                        ListItem.pop();
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation(itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item);
                            Text.debugLine("pages/NavigationDemo.ets(22:15)");
                            Text.width('100%');
                            Text.height(75);
                            Text.backgroundColor(Color.White);
                            Text.textAlign(TextAlign.Center);
                            Text.fontWeight(FontWeight.Bold);
                            Text.borderRadius(55);
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        ListItem.pop();
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.updateFuncByElmtId.set(elmtId, itemCreation);
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(item);
                            Text.debugLine("pages/NavigationDemo.ets(22:15)");
                            Text.width('100%');
                            Text.height(75);
                            Text.backgroundColor(Color.White);
                            Text.textAlign(TextAlign.Center);
                            Text.fontWeight(FontWeight.Bold);
                            Text.borderRadius(55);
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                        ListItem.pop();
                    };
                    if (isLazyCreate) {
                        observedShallowRender();
                    }
                    else {
                        observedDeepRender();
                    }
                }
            };
            this.forEachUpdateFunction(elmtId, this.arr, forEachItemGenFunction, undefined, true, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        List.pop();
        Navigation.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new NavigationDemo(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=NavigationDemo.js.map