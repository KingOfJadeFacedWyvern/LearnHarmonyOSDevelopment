export class ProductItem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.ProductInfo = undefined;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.ProductInfo !== undefined) {
            this.ProductInfo = params.ProductInfo;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Project/Hungry/Component/ProductItem.ets(8:5)");
            Row.width('100%');
            Row.padding(10);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777245, "type": 20000, params: [], "bundleName": "com.example.codemotioncloudclassroom", "moduleName": "entry" });
            Image.debugLine("pages/Project/Hungry/Component/ProductItem.ets(9:7)");
            Image.width(`90VP`);
            Image.aspectRatio(1);
            Image.borderRadius(11);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 2 });
            Column.debugLine("pages/Project/Hungry/Component/ProductItem.ets(13:7)");
            Column.margin({ left: 10, right: 10 });
            Column.alignItems(HorizontalAlign.Start);
            Column.layoutWeight(1);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.ProductInfo.name);
            Text.debugLine("pages/Project/Hungry/Component/ProductItem.ets(14:9)");
            Text.fontSize(20);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.fontWeight(FontWeight.Bold);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.ProductInfo.tag);
            Text.debugLine("pages/Project/Hungry/Component/ProductItem.ets(19:9)");
            Text.fontSize(12);
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.fontColor('#895F39');
            Text.backgroundColor('#FFF4E6');
            Text.padding({ left: 5, top: 2, right: 5, bottom: 2 });
            Text.borderRadius(2);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.ProductInfo.desc);
            Text.debugLine("pages/Project/Hungry/Component/ProductItem.ets(27:9)");
            Text.maxLines(1);
            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
            Text.fontSize(15);
            Text.fontColor('#A1A1A1');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create();
            Text.debugLine("pages/Project/Hungry/Component/ProductItem.ets(32:9)");
            Text.fontSize(12);
            Text.fontColor('#A1A1A1');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create(`朋售 ${this.ProductInfo.month_sale}`);
            Span.debugLine("pages/Project/Hungry/Component/ProductItem.ets(33:11)");
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create(' ');
            Span.debugLine("pages/Project/Hungry/Component/ProductItem.ets(34:11)");
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create(`好评率${this.ProductInfo.like_rate}`);
            Span.debugLine("pages/Project/Hungry/Component/ProductItem.ets(35:11)");
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Project/Hungry/Component/ProductItem.ets(40:9)");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create();
            Text.debugLine("pages/Project/Hungry/Component/ProductItem.ets(41:11)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create('$ ');
            Span.debugLine("pages/Project/Hungry/Component/ProductItem.ets(42:13)");
            Span.fontSize(10);
            Span.fontColor('#FD4A37');
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create(`${this.ProductInfo.price}`);
            Span.debugLine("pages/Project/Hungry/Component/ProductItem.ets(45:13)");
            Span.fontSize(15);
            Span.fontColor('#FD4A37');
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777238, "type": 20000, params: [], "bundleName": "com.example.codemotioncloudclassroom", "moduleName": "entry" });
            Image.debugLine("pages/Project/Hungry/Component/ProductItem.ets(50:11)");
            Image.width(16);
            Image.aspectRatio(1);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Row.pop();
        Column.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=ProductItem.js.map