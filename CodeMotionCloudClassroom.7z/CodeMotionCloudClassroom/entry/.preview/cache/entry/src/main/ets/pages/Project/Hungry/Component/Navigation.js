export class Navigation1 extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    NavigatorItem(isSelectes, title, subTitle, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Project/Hungry/Component/Navigation.ets(4:5)");
            Column.width(55);
            Column.margin({ top: 15, bottom: 10 });
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // Badge包裹文字
            Badge.create({
                value: subTitle,
                position: BadgePosition.RightTop,
                style: {
                    color: '#CBCBCB',
                    fontSize: 8,
                    badgeSize: 8,
                    badgeColor: Color.Transparent
                }
            });
            Badge.debugLine("pages/Project/Hungry/Component/Navigation.ets(6:7)");
            // Badge包裹文字
            Badge.layoutWeight(1);
            if (!isInitialRender) {
                // Badge包裹文字
                Badge.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(title);
            Text.debugLine("pages/Project/Hungry/Component/Navigation.ets(16:9)");
            Text.fontSize(12);
            Text.fontWeight(isSelectes ? FontWeight.Bold : FontWeight.Normal);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        // Badge包裹文字
        Badge.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //   红色线条
            Text.create();
            Text.debugLine("pages/Project/Hungry/Component/Navigation.ets(22:7)");
            //   红色线条
            Text.width(16);
            //   红色线条
            Text.height(1);
            //   红色线条
            Text.backgroundColor(isSelectes ? Color.Red : '#FBFBFB');
            //   红色线条
            Text.borderRadius(10);
            if (!isInitialRender) {
                //   红色线条
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        //   红色线条
        Text.pop();
        Column.pop();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Project/Hungry/Component/Navigation.ets(33:5)");
            Row.width('100%');
            Row.height(45);
            Row.backgroundColor('#FBFBFB');
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.NavigatorItem.bind(this)(true, '点餐');
        this.NavigatorItem.bind(this)(false, '评价', '1024');
        this.NavigatorItem.bind(this)(false, '品牌', '故事');
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('好友接单');
            Text.debugLine("pages/Project/Hungry/Component/Navigation.ets(37:7)");
            Text.fontSize(12);
            Text.fontColor("#E3002B");
            Text.fontWeight(FontWeight.Bold);
            Text.width(55);
            Text.height(20);
            Text.border({ width: 1, color: "#E3002B" });
            Text.borderRadius(15);
            Text.textAlign(TextAlign.Center);
            Text.margin({ left: 100 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=Navigation.js.map