import promptAction from '@ohos:promptAction';
/*
AppStorage是应用全局的UI状态存储，是和应用的进程绑定的，由UI框架在应用程序启动时创建，为应用程序UI状态属性提供中央存储。
和LocalStorage不同的是，LocalStorage是页面级的，通常应用于页面内的数据共享，而AppStorage是应用级的全局状态共享，还相当于整个应用的“中枢”。
注意：AppStorage也是基于内存进行状态存储管理。
*/
AppStorage.SetOrCreate('person', { name: '小小', age: 24 }); // 如果有引用AppStorage，没有的话，它会创建AppStorage
class AppStorageDemo extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__person = this.createStorageLink('person', {}, "person");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        this.__person.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get person() {
        return this.__person.get();
    }
    set person(newValue) {
        this.__person.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 11 });
            Column.debugLine("pages/ManagePageState/AppStorageDemo.ets(16:5)");
            Column.width('100%');
            Column.height('100%');
            Column.justifyContent(FlexAlign.Center);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`根组件-AppStorage person信息；${this.person.name}-${this.person.age}`);
            Text.debugLine("pages/ManagePageState/AppStorageDemo.ets(17:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel(`根组件-给age加1`);
            Button.debugLine("pages/ManagePageState/AppStorageDemo.ets(18:7)");
            Button.onClick(() => {
                this.person.age += 1;
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Divider.create();
            Divider.debugLine("pages/ManagePageState/AppStorageDemo.ets(23:7)");
            if (!isInitialRender) {
                Divider.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new comA(this, {}, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Divider.create();
            Divider.debugLine("pages/ManagePageState/AppStorageDemo.ets(25:7)");
            if (!isInitialRender) {
                Divider.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new ComB(this, {}, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class comA extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__person = this.createStorageLink('person', {}, "person");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        this.__person.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get person() {
        return this.__person.get();
    }
    set person(newValue) {
        this.__person.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 11 });
            Column.debugLine("pages/ManagePageState/AppStorageDemo.ets(39:5)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(`A组件-AppStorage person信息；${this.person.name}-${this.person.age}`);
            Text.debugLine("pages/ManagePageState/AppStorageDemo.ets(40:7)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel(`AA组件-给age加1`);
            Button.debugLine("pages/ManagePageState/AppStorageDemo.ets(41:7)");
            Button.onClick(() => {
                this.person.age += 1;
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class ComB extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 5 });
            Column.debugLine("pages/ManagePageState/AppStorageDemo.ets(54:5)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel(`获取AppStorage中的值`);
            Button.debugLine("pages/ManagePageState/AppStorageDemo.ets(55:7)");
            Button.onClick(() => {
                const person = AppStorage.Get(`person`);
                promptAction.showToast({ message: person.name + '-' + person.age });
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Divider.create();
            Divider.debugLine("pages/ManagePageState/AppStorageDemo.ets(60:7)");
            if (!isInitialRender) {
                Divider.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 通过API方式来操作AppStorage UI级别状态值
            Button.createWithLabel(`设置AppStorage中的值`);
            Button.debugLine("pages/ManagePageState/AppStorageDemo.ets(62:7)");
            // 通过API方式来操作AppStorage UI级别状态值
            Button.onClick(() => {
                AppStorage.Set(`person`, { name: '大大', age: 20 });
            });
            if (!isInitialRender) {
                // 通过API方式来操作AppStorage UI级别状态值
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 通过API方式来操作AppStorage UI级别状态值
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Divider.create();
            Divider.debugLine("pages/ManagePageState/AppStorageDemo.ets(67:7)");
            if (!isInitialRender) {
                Divider.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 通过API方式来操作AppStorage UI级别状态值
            Button.createWithLabel(`link方式获取 / 设置值`);
            Button.debugLine("pages/ManagePageState/AppStorageDemo.ets(69:7)");
            // 通过API方式来操作AppStorage UI级别状态值
            Button.onClick(() => {
                // 另一种获取值方法
                const Link = AppStorage.Link('person');
                // 设置值
                Link.set({
                    name: Link.get().name,
                    age: Link.get().age += 1
                });
                promptAction.showToast({ message: Link.get().name + '-' + Link.get().age });
            });
            if (!isInitialRender) {
                // 通过API方式来操作AppStorage UI级别状态值
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        // 通过API方式来操作AppStorage UI级别状态值
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new AppStorageDemo(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=AppStorageDemo.js.map