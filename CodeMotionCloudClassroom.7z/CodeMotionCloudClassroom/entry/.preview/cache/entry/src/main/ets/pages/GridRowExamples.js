"use strict";
class GridRowExamples extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__message = new ObservedPropertySimplePU('Hello World', this, "message");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get message() {
        return this.__message.get();
    }
    set message(newValue) {
        this.__message.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            GridRow.create();
            GridRow.debugLine("pages/GridRowExamples.ets(8:5)");
            GridRow.width('100%');
            GridRow.height(2000);
            if (!isInitialRender) {
                GridRow.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 大布局
            GridCol.create({ span: 12 });
            GridCol.debugLine("pages/GridRowExamples.ets(10:7)");
            if (!isInitialRender) {
                // 大布局
                GridCol.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            GridRow.create();
            GridRow.debugLine("pages/GridRowExamples.ets(11:9)");
            if (!isInitialRender) {
                GridRow.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            GridCol.create({ span: 2 });
            GridCol.debugLine("pages/GridRowExamples.ets(12:11)");
            GridCol.backgroundColor(Color.Gray);
            GridCol.width('100%');
            GridCol.height('10%');
            if (!isInitialRender) {
                GridCol.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('Left');
            Text.debugLine("pages/GridRowExamples.ets(13:13)");
            Text.width('100%');
            Text.height('100%');
            Text.textAlign(TextAlign.Center);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        GridCol.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            GridCol.create({ span: 10 });
            GridCol.debugLine("pages/GridRowExamples.ets(22:11)");
            GridCol.backgroundColor(Color.Blue);
            GridCol.width('100%');
            GridCol.height('10%');
            if (!isInitialRender) {
                GridCol.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('Right');
            Text.debugLine("pages/GridRowExamples.ets(23:13)");
            Text.width('100%');
            Text.height('100%');
            Text.textAlign(TextAlign.Center);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        GridCol.pop();
        GridRow.pop();
        // 大布局
        GridCol.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // Footer 小布局
            GridCol.create({ span: 12 });
            GridCol.debugLine("pages/GridRowExamples.ets(36:7)");
            // Footer 小布局
            GridCol.backgroundColor(Color.Pink);
            if (!isInitialRender) {
                // Footer 小布局
                GridCol.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('Footer');
            Text.debugLine("pages/GridRowExamples.ets(37:9)");
            Text.width('100%');
            Text.height('2%');
            Text.textAlign(TextAlign.Center);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        // Footer 小布局
        GridCol.pop();
        GridRow.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new GridRowExamples(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=GridRowExamples.js.map