import Prompt from '@ohos:prompt';
import router from '@ohos:router';
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__message = new ObservedPropertySimplePU('Hello World', this, "message");
        this.__login = new ObservedPropertySimplePU(false, this, "login");
        this.__userPhone = new ObservedPropertySimplePU("", this, "userPhone");
        this.__userPassword = new ObservedPropertySimplePU("", this, "userPassword");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
        if (params.login !== undefined) {
            this.login = params.login;
        }
        if (params.userPhone !== undefined) {
            this.userPhone = params.userPhone;
        }
        if (params.userPassword !== undefined) {
            this.userPassword = params.userPassword;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
        this.__login.purgeDependencyOnElmtId(rmElmtId);
        this.__userPhone.purgeDependencyOnElmtId(rmElmtId);
        this.__userPassword.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        this.__login.aboutToBeDeleted();
        this.__userPhone.aboutToBeDeleted();
        this.__userPassword.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get message() {
        return this.__message.get();
    }
    set message(newValue) {
        this.__message.set(newValue);
    }
    get login() {
        return this.__login.get();
    }
    set login(newValue) {
        this.__login.set(newValue);
    }
    get userPhone() {
        return this.__userPhone.get();
    }
    set userPhone(newValue) {
        this.__userPhone.set(newValue);
    }
    get userPassword() {
        return this.__userPassword.get();
    }
    set userPassword(newValue) {
        this.__userPassword.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Stack.create();
            Stack.debugLine("pages/Test.ets(13:5)");
            Stack.width("100%");
            Stack.height("100%");
            Stack.backgroundColor(Color.White);
            if (!isInitialRender) {
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/Test.ets(15:7)");
            Column.width("100%");
            Column.height("100%");
            Column.backgroundColor(Color.White);
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777228, "type": 20000, params: [], "bundleName": "com.example.codemotioncloudclassroom", "moduleName": "entry" });
            Image.debugLine("pages/Test.ets(18:9)");
            Image.width(100);
            Image.height(100);
            Image.margin({ top: 80 });
            Image.borderRadius(15);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("登录界面");
            Text.debugLine("pages/Test.ets(21:9)");
            __Text__indexText(Color.Black, 24, 600);
            Text.margin({ top: 30 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("登录账号以使用更多服务");
            Text.debugLine("pages/Test.ets(22:9)");
            __Text__indexText(Color.Gray, 18, 400);
            Text.margin({ top: 10 });
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            TextInput.create({ placeholder: "请输入账号", text: "138888888" });
            TextInput.debugLine("pages/Test.ets(25:9)");
            TextInput.width("90%");
            TextInput.margin({ top: 50 });
            TextInput.type(InputType.PhoneNumber);
            TextInput.onChange((value) => {
                this.userPhone = value;
            });
            TextInput.maxLength(11);
            if (!isInitialRender) {
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //Divider().strokeWidth(1).color(Color.Red).margin({ left: 20, right: 20, top: 20 })
            TextInput.create({ placeholder: "请输入密码", text: "cui" });
            TextInput.debugLine("pages/Test.ets(36:9)");
            //Divider().strokeWidth(1).color(Color.Red).margin({ left: 20, right: 20, top: 20 })
            TextInput.width("90%");
            //Divider().strokeWidth(1).color(Color.Red).margin({ left: 20, right: 20, top: 20 })
            TextInput.margin({ top: 20 });
            //Divider().strokeWidth(1).color(Color.Red).margin({ left: 20, right: 20, top: 20 })
            TextInput.type(InputType.Password);
            //Divider().strokeWidth(1).color(Color.Red).margin({ left: 20, right: 20, top: 20 })
            TextInput.onChange((value) => {
                this.userPassword = value;
            });
            if (!isInitialRender) {
                //Divider().strokeWidth(1).color(Color.Red).margin({ left: 20, right: 20, top: 20 })
                TextInput.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Test.ets(42:9)");
            Row.width("90%");
            Row.height(50);
            Row.margin({ left: 20, right: 20, top: 10 });
            Row.backgroundColor(Color.White);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("短信验证码登录");
            Text.debugLine("pages/Test.ets(43:11)");
            __Text__indexText("#0B63FE", 16, 400);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Blank.create();
            Blank.debugLine("pages/Test.ets(44:11)");
            if (!isInitialRender) {
                Blank.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Blank.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("忘记密码?");
            Text.debugLine("pages/Test.ets(45:11)");
            __Text__indexText("#0B63FE", 16, 400);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithLabel("登录");
            Button.debugLine("pages/Test.ets(52:9)");
            Button.width("80%");
            Button.margin({ top: 40 });
            Button.height(50);
            Button.onClick(() => {
                if (this.userPhone.length == 0) {
                    Prompt.showToast({ message: "账号不能为空" });
                    return;
                }
                else if (this.userPassword.length == 0) {
                    Prompt.showToast({ message: "密码不能为空" });
                    return;
                }
                else {
                    //开始登录
                    this.login = true;
                    setTimeout(() => {
                        router.replaceUrl({ url: "pages/MainPage", params: {
                                userName: this.userPhone,
                                userPassword: this.userPassword,
                            } });
                    }, 3000);
                }
            });
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("注册帐号");
            Text.debugLine("pages/Test.ets(72:9)");
            __Text__indexText("#0B63FE", 16, 400);
            Text.margin(20);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("其他登录方式");
            Text.debugLine("pages/Test.ets(73:9)");
            __Text__indexText(Color.Gray, 16, 400);
            Text.margin(20);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Test.ets(76:9)");
            Row.width("90%");
            Row.height(70);
            Row.justifyContent(FlexAlign.SpaceAround);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild();
            Button.debugLine("pages/Test.ets(78:11)");
            Button.type(ButtonType.Circle);
            __Button__indexButton(() => {
                Prompt.showToast({ message: "Apple--登录" });
            }, Color.Brown, 60);
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("Apple");
            Text.debugLine("pages/Test.ets(79:13)");
            __Text__indexText();
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild();
            Button.debugLine("pages/Test.ets(85:11)");
            Button.backgroundColor(Color.Brown);
            Button.type(ButtonType.Circle);
            __Button__indexButton(() => {
                Prompt.showToast({ message: "微信--登录" });
            }, Color.Red, 60);
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("微信");
            Text.debugLine("pages/Test.ets(86:13)");
            __Text__indexText();
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Button.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Button.createWithChild();
            Button.debugLine("pages/Test.ets(93:11)");
            Button.type(ButtonType.Circle);
            __Button__indexButton(() => {
                Prompt.showToast({ message: "QQ--登录" });
            }, Color.Pink, 60);
            if (!isInitialRender) {
                Button.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create("QQ");
            Text.debugLine("pages/Test.ets(94:13)");
            __Text__indexText();
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Button.pop();
        Row.pop();
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            if (this.login) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation((elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        LoadingProgress.create();
                        LoadingProgress.debugLine("pages/Test.ets(110:9)");
                        LoadingProgress.width(50);
                        LoadingProgress.height(50);
                        LoadingProgress.color(Color.Blue);
                        if (!isInitialRender) {
                            LoadingProgress.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    });
                });
            }
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
function __Button__indexButton(click, co, size) {
    Button.width(size);
    Button.height(size);
    Button.backgroundColor(co);
    Button.onClick(() => {
        click();
    });
}
function __Text__indexText(co, fs, fw) {
    Text.fontSize(fs);
    Text.fontColor(co);
    Text.fontWeight(fw);
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Index(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Test.js.map