import promptAction from '@ohos:promptAction';
class TabsBarItem {
}
class TabsDemo1 extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__tabsBarList = new ObservedPropertyObjectPU([
            {
                title: '主页',
                defaultImage: { "id": 16777223, "type": 20000, params: [], "bundleName": "com.example.codemotioncloudclassroom", "moduleName": "entry" },
                selectedImage: { "id": 16777226, "type": 20000, params: [], "bundleName": "com.example.codemotioncloudclassroom", "moduleName": "entry" },
                color: Color.Pink
            },
            {
                title: '信息',
                defaultImage: { "id": 16777227, "type": 20000, params: [], "bundleName": "com.example.codemotioncloudclassroom", "moduleName": "entry" },
                selectedImage: { "id": 16777229, "type": 20000, params: [], "bundleName": "com.example.codemotioncloudclassroom", "moduleName": "entry" },
                color: Color.Pink
            },
            {
                title: '图片',
                defaultImage: { "id": 16777219, "type": 20000, params: [], "bundleName": "com.example.codemotioncloudclassroom", "moduleName": "entry" },
                selectedImage: { "id": 16777230, "type": 20000, params: [], "bundleName": "com.example.codemotioncloudclassroom", "moduleName": "entry" },
                color: Color.Pink
            },
            {
                title: '你的',
                defaultImage: { "id": 16777225, "type": 20000, params: [], "bundleName": "com.example.codemotioncloudclassroom", "moduleName": "entry" },
                selectedImage: { "id": 16777218, "type": 20000, params: [], "bundleName": "com.example.codemotioncloudclassroom", "moduleName": "entry" },
                color: Color.Pink
            }
        ], this, "tabsBarList");
        this.__activeImage = new ObservedPropertySimplePU(0 // 控制选中value (主页、信息、图片、你的)
        , this, "activeImage");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.tabsBarList !== undefined) {
            this.tabsBarList = params.tabsBarList;
        }
        if (params.activeImage !== undefined) {
            this.activeImage = params.activeImage;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__tabsBarList.purgeDependencyOnElmtId(rmElmtId);
        this.__activeImage.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__tabsBarList.aboutToBeDeleted();
        this.__activeImage.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get tabsBarList() {
        return this.__tabsBarList.get();
    }
    set tabsBarList(newValue) {
        this.__tabsBarList.set(newValue);
    }
    TabsBarBuilder(item, index, parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create({ space: 5 });
            Column.debugLine("pages/TabsDemo1.ets(40:5)");
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create(this.activeImage === index ? item.selectedImage : item.defaultImage);
            Image.debugLine("pages/TabsDemo1.ets(41:7)");
            Image.width(20);
            Image.aspectRatio(1);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(item.title);
            Text.debugLine("pages/TabsDemo1.ets(44:7)");
            Text.fontSize(this.activeImage === index ? 16 : 12);
            Text.fontColor(this.activeImage === index ? Color.Blue : Color.Black);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Column.pop();
    }
    get activeImage() {
        return this.__activeImage.get();
    }
    set activeImage(newValue) {
        this.__activeImage.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            //barPosition: BarPosition.End控制页签在下面，还有一个值Start表示是在上面页签
            Tabs.create({ barPosition: BarPosition.End });
            Tabs.debugLine("pages/TabsDemo1.ets(55:5)");
            //barPosition: BarPosition.End控制页签在下面，还有一个值Start表示是在上面页签
            Tabs.onChange((value) => {
                this.activeImage = value;
                promptAction.showToast({ message: '选择下标：' + this.activeImage });
            });
            if (!isInitialRender) {
                //barPosition: BarPosition.End控制页签在下面，还有一个值Start表示是在上面页签
                Tabs.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, index) => {
                const item = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    TabContent.create(() => {
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            Text.create(index.toString());
                            Text.debugLine("pages/TabsDemo1.ets(58:11)");
                            Text.fontSize(30);
                            if (!isInitialRender) {
                                Text.pop();
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                        Text.pop();
                    });
                    TabContent.tabBar({ builder: () => {
                            this.TabsBarBuilder.call(this, item, index);
                        } });
                    TabContent.backgroundColor(item.color);
                    TabContent.debugLine("pages/TabsDemo1.ets(57:9)");
                    if (!isInitialRender) {
                        TabContent.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                TabContent.pop();
            };
            this.forEachUpdateFunction(elmtId, this.tabsBarList, forEachItemGenFunction, undefined, true, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        //barPosition: BarPosition.End控制页签在下面，还有一个值Start表示是在上面页签
        Tabs.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new TabsDemo1(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=TabsDemo1.js.map