"use strict";
class BuilderParamTest extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__message = new ObservedPropertySimplePU('Hello World', this, "message");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get message() {
        return this.__message.get();
    }
    set message(newValue) {
        this.__message.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Column.create();
            Column.debugLine("pages/BuilderParamTest.ets(7:5)");
            Column.width('100%');
            Column.height('100%');
            if (!isInitialRender) {
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new MyComp(this, {
                        info1: '文本A',
                        info2: '文本B',
                        MyBuilderParam: () => {
                            this.observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                Button.createWithLabel('第一行按钮');
                                Button.debugLine("pages/BuilderParamTest.ets(12:9)");
                                if (!isInitialRender) {
                                    Button.pop();
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                            Button.pop();
                        }
                    }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new MyComp(this, {
                        info1: '文本C', info2: '文本D',
                        MyBuilderParam: () => {
                            this.observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                Text.create('第二行文本');
                                Text.debugLine("pages/BuilderParamTest.ets(16:9)");
                                Text.width(`100VP`);
                                Text.height(`100VP`);
                                Text.backgroundColor(Color.Yellow);
                                if (!isInitialRender) {
                                    Text.pop();
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                            Text.pop();
                        }
                    }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new MyComp(this, {
                        info1: '文本E', info2: '文本F',
                        MyBuilderParam: () => {
                            this.observeComponentCreation((elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                Image.create({ "id": 16777235, "type": 20000, params: [], "bundleName": "com.example.codemotioncloudclassroom", "moduleName": "entry" });
                                Image.debugLine("pages/BuilderParamTest.ets(23:9)");
                                Image.width(100);
                                if (!isInitialRender) {
                                    Image.pop();
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            });
                        }
                    }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new MyComp(this, { info1: '文本E', info2: '文本F' }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class MyComp extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.info1 = undefined;
        this.info2 = undefined;
        this.MyBuilderParam = this.DefaultBuilder;
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.info1 !== undefined) {
            this.info1 = params.info1;
        }
        if (params.info2 !== undefined) {
            this.info2 = params.info2;
        }
        if (params.MyBuilderParam !== undefined) {
            this.MyBuilderParam = params.MyBuilderParam;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 当在自定义Component中使用了@BuilderParam装饰器装饰的方法，在外部组件中调用该Component时必须传入符合@BuilderParam装饰方法定义的参数内容来初始化@BuilderParam装饰器装饰的方法，否则会显示异常。
    DefaultBuilder(parent = null) {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('默认文本');
            Text.debugLine("pages/BuilderParamTest.ets(43:5)");
            Text.width(100);
            Text.height(100);
            Text.backgroundColor(Color.Red);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/BuilderParamTest.ets(53:5)");
            Row.width('100%');
            Row.backgroundColor(Color.Pink);
            Row.margin(5);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.info1);
            Text.debugLine("pages/BuilderParamTest.ets(54:7)");
            Text.width(`100}VP`);
            Text.height(`100VP`);
            Text.backgroundColor(Color.Orange);
            Text.textAlign(TextAlign.Center);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create(this.info2);
            Text.debugLine("pages/BuilderParamTest.ets(59:7)");
            Text.width(`100}VP`);
            Text.height(`100VP`);
            Text.backgroundColor(Color.Green);
            Text.textAlign(TextAlign.Center);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.MyBuilderParam.bind(this)();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new BuilderParamTest(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=BuilderParamTest.js.map