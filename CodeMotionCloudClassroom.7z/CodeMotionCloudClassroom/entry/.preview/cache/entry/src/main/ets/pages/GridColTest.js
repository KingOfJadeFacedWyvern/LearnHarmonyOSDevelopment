"use strict";
class GridColTest extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__message = new ObservedPropertySimplePU('Hello World', this, "message");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.message !== undefined) {
            this.message = params.message;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__message.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__message.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get message() {
        return this.__message.get();
    }
    set message(newValue) {
        this.__message.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            GridRow.create();
            GridRow.debugLine("pages/GridColTest.ets(7:5)");
            if (!isInitialRender) {
                GridRow.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 子组件GridCol  GridCol组件作为GridRow组件的子组件，通过给GridCol传参或者设置属性两种方式，设置span（占用列数），offset（偏移列数），order（元素序号）的值。
            // span（占用列数）子组件占栅格布局的列数，决定了子组件的宽度，默认为1。span可以指定为number类型，表示子组件在所有尺寸设备下占用的列数相同。
            // offset（偏移列数）栅格子组件相对于前一个子组件的偏移列数，默认为0。可以指定offset为number类型，表示子组件偏移相同列数。
            GridCol.create({ order: 5 });
            GridCol.debugLine("pages/GridColTest.ets(11:7)");
            // 子组件GridCol  GridCol组件作为GridRow组件的子组件，通过给GridCol传参或者设置属性两种方式，设置span（占用列数），offset（偏移列数），order（元素序号）的值。
            // span（占用列数）子组件占栅格布局的列数，决定了子组件的宽度，默认为1。span可以指定为number类型，表示子组件在所有尺寸设备下占用的列数相同。
            // offset（偏移列数）栅格子组件相对于前一个子组件的偏移列数，默认为0。可以指定offset为number类型，表示子组件偏移相同列数。
            GridCol.backgroundColor(Color.Green);
            if (!isInitialRender) {
                // 子组件GridCol  GridCol组件作为GridRow组件的子组件，通过给GridCol传参或者设置属性两种方式，设置span（占用列数），offset（偏移列数），order（元素序号）的值。
                // span（占用列数）子组件占栅格布局的列数，决定了子组件的宽度，默认为1。span可以指定为number类型，表示子组件在所有尺寸设备下占用的列数相同。
                // offset（偏移列数）栅格子组件相对于前一个子组件的偏移列数，默认为0。可以指定offset为number类型，表示子组件偏移相同列数。
                GridCol.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('1');
            Text.debugLine("pages/GridColTest.ets(12:9)");
            Text.width('100%');
            Text.height(`50VP`);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        // 子组件GridCol  GridCol组件作为GridRow组件的子组件，通过给GridCol传参或者设置属性两种方式，设置span（占用列数），offset（偏移列数），order（元素序号）的值。
        // span（占用列数）子组件占栅格布局的列数，决定了子组件的宽度，默认为1。span可以指定为number类型，表示子组件在所有尺寸设备下占用的列数相同。
        // offset（偏移列数）栅格子组件相对于前一个子组件的偏移列数，默认为0。可以指定offset为number类型，表示子组件偏移相同列数。
        GridCol.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            GridCol.create({ order: 4 });
            GridCol.debugLine("pages/GridColTest.ets(18:7)");
            GridCol.backgroundColor(Color.Red);
            if (!isInitialRender) {
                GridCol.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('2');
            Text.debugLine("pages/GridColTest.ets(19:9)");
            Text.width('100%');
            Text.height(`50VP`);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        GridCol.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            GridCol.create({ order: 3 });
            GridCol.debugLine("pages/GridColTest.ets(25:7)");
            GridCol.backgroundColor(Color.Orange);
            if (!isInitialRender) {
                GridCol.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('3');
            Text.debugLine("pages/GridColTest.ets(26:9)");
            Text.width('100%');
            Text.height(`50VP`);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        GridCol.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            GridCol.create({ order: 2 });
            GridCol.debugLine("pages/GridColTest.ets(32:7)");
            GridCol.backgroundColor(Color.Gray);
            if (!isInitialRender) {
                GridCol.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('4');
            Text.debugLine("pages/GridColTest.ets(33:9)");
            Text.width('100%');
            Text.height(`50VP`);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        GridCol.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            GridCol.create({ order: 1 });
            GridCol.debugLine("pages/GridColTest.ets(39:7)");
            GridCol.backgroundColor(Color.Pink);
            if (!isInitialRender) {
                GridCol.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('5');
            Text.debugLine("pages/GridColTest.ets(40:9)");
            Text.width('100%');
            Text.height(`50VP`);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        GridCol.pop();
        GridRow.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new GridColTest(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=GridColTest.js.map