import { Cart } from '@bundle:com.example.codemotioncloudclassroom/entry/ets/pages/Project/Hungry/Component/Catr';
import { Footer } from '@bundle:com.example.codemotioncloudclassroom/entry/ets/pages/Project/Hungry/Component/Footer';
import { Navigation1 } from '@bundle:com.example.codemotioncloudclassroom/entry/ets/pages/Project/Hungry/Component/Navigation';
import { ProductsMenu } from '@bundle:com.example.codemotioncloudclassroom/entry/ets/pages/Project/Hungry/Component/ProductsMenu';
import http from '@ohos:net.http';
// 创建 HTTP Request对象
const request = http.createHttp();
class Hungry extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__ShowCart = new ObservedPropertySimplePU(false, this, "ShowCart");
        this.__categroyList = new ObservedPropertyObjectPU([], this, "categroyList");
        this.Address = 'http://1a13212e.r11.cpolar.top/infos';
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.ShowCart !== undefined) {
            this.ShowCart = params.ShowCart;
        }
        if (params.categroyList !== undefined) {
            this.categroyList = params.categroyList;
        }
        if (params.Address !== undefined) {
            this.Address = params.Address;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__ShowCart.purgeDependencyOnElmtId(rmElmtId);
        this.__categroyList.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__ShowCart.aboutToBeDeleted();
        this.__categroyList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get ShowCart() {
        return this.__ShowCart.get();
    }
    set ShowCart(newValue) {
        this.__ShowCart.set(newValue);
    }
    get categroyList() {
        return this.__categroyList.get();
    }
    set categroyList(newValue) {
        this.__categroyList.set(newValue);
    }
    // 在build前执行
    aboutToAppear() {
        request.request('http://1a13212e.r11.cpolar.top/infos')
            .then((ResponseType) => {
            const categroyList = JSON.parse(ResponseType.result);
            this.categroyList = categroyList;
        });
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 层叠布局
            Stack.create({ alignContent: Alignment.Bottom });
            Stack.debugLine("pages/Project/Hungry/Hungry.ets(28:5)");
            // 层叠布局
            Stack.width('100%');
            // 层叠布局
            Stack.height('100%');
            if (!isInitialRender) {
                // 层叠布局
                Stack.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 商品区
            Column.create();
            Column.debugLine("pages/Project/Hungry/Hungry.ets(30:7)");
            // 商品区
            Column.width('100%');
            // 商品区
            Column.height('100%');
            if (!isInitialRender) {
                // 商品区
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new 
                    // 导航部分
                    Navigation1(this, {}, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new 
                    // 商品部分
                    ProductsMenu(this, { categoryList: this.__categoryList }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        // 商品区
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            If.create();
            // 购物车
            if (this.ShowCart) {
                this.ifElseBranchUpdateFunction(0, () => {
                    {
                        this.observeComponentCreation((elmtId, isInitialRender) => {
                            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                            if (isInitialRender) {
                                ViewPU.create(new Cart(this, {}, undefined, elmtId));
                            }
                            else {
                                this.updateStateVarsOfChildByElmtId(elmtId, {});
                            }
                            ViewStackProcessor.StopGetAccessRecording();
                        });
                    }
                });
            }
            // 结算区
            else {
                If.branchId(1);
            }
            if (!isInitialRender) {
                If.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        If.pop();
        {
            this.observeComponentCreation((elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                if (isInitialRender) {
                    ViewPU.create(new 
                    // 结算区
                    Footer(this, { ShowCart: this.__ShowCart }, undefined, elmtId));
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
                ViewStackProcessor.StopGetAccessRecording();
            });
        }
        // 层叠布局
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new Hungry(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=Hungry.js.map