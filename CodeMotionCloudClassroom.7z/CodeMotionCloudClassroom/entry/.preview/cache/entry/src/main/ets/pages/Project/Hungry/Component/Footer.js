export class Footer extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.__ShowCart = new SynchedPropertySimpleTwoWayPU(params.ShowCart, this, "ShowCart");
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__ShowCart.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__ShowCart.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    get ShowCart() {
        return this.__ShowCart.get();
    }
    set ShowCart(newValue) {
        this.__ShowCart.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Project/Hungry/Component/Footer.ets(6:5)");
            Row.width('100%');
            Row.height(50);
            Row.backgroundColor(Color.White);
            Row.border({ width: { top: 0.5 }, color: "#FEF6E5" });
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Row.create();
            Row.debugLine("pages/Project/Hungry/Component/Footer.ets(7:7)");
            Row.margin({ left: 15, right: 15 });
            Row.layoutWeight(1);
            if (!isInitialRender) {
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 左侧图标背景
            Row.create();
            Row.debugLine("pages/Project/Hungry/Component/Footer.ets(9:9)");
            // 左侧图标背景
            Row.height('90%');
            // 左侧图标背景
            Row.aspectRatio(1);
            // 左侧图标背景
            Row.backgroundColor('#CBCBCB');
            // 左侧图标背景
            Row.borderRadius(25);
            // 左侧图标背景
            Row.alignItems(VerticalAlign.Center);
            // 左侧图标背景
            Row.justifyContent(FlexAlign.Center);
            // 左侧图标背景
            Row.margin({ left: 25, right: 10, bottom: 10 });
            // 左侧图标背景
            Row.onClick(() => {
                this.ShowCart = !this.ShowCart;
            });
            if (!isInitialRender) {
                // 左侧图标背景
                Row.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Badge.create({
                value: '5',
                position: BadgePosition.RightTop,
                style: { badgeSize: 15, badgeColor: '#04B3FF' }
            });
            Badge.debugLine("pages/Project/Hungry/Component/Footer.ets(10:11)");
            if (!isInitialRender) {
                Badge.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Image.create({ "id": 16777236, "type": 20000, params: [], "bundleName": "com.example.codemotioncloudclassroom", "moduleName": "entry" });
            Image.debugLine("pages/Project/Hungry/Component/Footer.ets(15:13)");
            Image.width(30);
            Image.aspectRatio(1);
            if (!isInitialRender) {
                Image.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Badge.pop();
        // 左侧图标背景
        Row.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            // 设置礤文字
            Column.create();
            Column.debugLine("pages/Project/Hungry/Component/Footer.ets(31:9)");
            // 设置礤文字
            Column.alignItems(HorizontalAlign.Start);
            // 设置礤文字
            Column.padding({ left: 15 });
            // 设置礤文字
            Column.layoutWeight(1);
            if (!isInitialRender) {
                // 设置礤文字
                Column.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create();
            Text.debugLine("pages/Project/Hungry/Component/Footer.ets(32:11)");
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create('￥');
            Span.debugLine("pages/Project/Hungry/Component/Footer.ets(33:13)");
            Span.fontSize(12);
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Span.create('20');
            Span.debugLine("pages/Project/Hungry/Component/Footer.ets(34:13)");
            Span.fontSize(24);
            if (!isInitialRender) {
                Span.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('另需配送费$10');
            Text.debugLine("pages/Project/Hungry/Component/Footer.ets(37:11)");
            Text.fontSize(12);
            Text.fontColor('#C1C1C1');
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        // 设置礤文字
        Column.pop();
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            Text.create('去结算');
            Text.debugLine("pages/Project/Hungry/Component/Footer.ets(45:9)");
            Text.padding(10);
            Text.width(68);
            Text.backgroundColor('#989898');
            Text.borderRadius(55);
            Text.textAlign(TextAlign.Center);
            if (!isInitialRender) {
                Text.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        Text.pop();
        Row.pop();
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
//# sourceMappingURL=Footer.js.map