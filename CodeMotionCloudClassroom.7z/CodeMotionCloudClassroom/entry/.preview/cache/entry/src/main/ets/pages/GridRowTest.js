"use strict";
class GridRowTest extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1) {
        super(parent, __localStorage, elmtId);
        this.bgColor = [
            Color.Green,
            Color.Blue,
            Color.Brown,
            Color.Orange,
            Color.Green,
            Color.Blue,
            Color.Brown,
            Color.Orange,
            Color.Green,
            Color.Blue,
            Color.Brown,
            Color.Orange,
            Color.Gray
        ];
        this.setInitiallyProvidedValue(params);
    }
    setInitiallyProvidedValue(params) {
        if (params.bgColor !== undefined) {
            this.bgColor = params.bgColor;
        }
    }
    updateStateVars(params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            GridRow.create({ columns: 8 });
            GridRow.debugLine("pages/GridRowTest.ets(25:5)");
            if (!isInitialRender) {
                GridRow.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        this.observeComponentCreation((elmtId, isInitialRender) => {
            ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
            ForEach.create();
            const forEachItemGenFunction = (_item, index) => {
                const item = _item;
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    GridCol.create({ offset: 2 });
                    GridCol.debugLine("pages/GridRowTest.ets(27:9)");
                    GridCol.width('100%');
                    GridCol.height(50);
                    GridCol.backgroundColor(item);
                    if (!isInitialRender) {
                        GridCol.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                this.observeComponentCreation((elmtId, isInitialRender) => {
                    ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                    Text.create(`${index + 1}`);
                    Text.debugLine("pages/GridRowTest.ets(28:11)");
                    if (!isInitialRender) {
                        Text.pop();
                    }
                    ViewStackProcessor.StopGetAccessRecording();
                });
                Text.pop();
                GridCol.pop();
            };
            this.forEachUpdateFunction(elmtId, this.bgColor, forEachItemGenFunction, undefined, true, false);
            if (!isInitialRender) {
                ForEach.pop();
            }
            ViewStackProcessor.StopGetAccessRecording();
        });
        ForEach.pop();
        GridRow.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
ViewStackProcessor.StartGetAccessRecordingFor(ViewStackProcessor.AllocateNewElmetIdForNextComponent());
loadDocument(new GridRowTest(undefined, {}));
ViewStackProcessor.StopGetAccessRecording();
//# sourceMappingURL=GridRowTest.js.map